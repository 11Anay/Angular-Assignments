import { Component } from '@angular/core';

@Component({
  selector: 'app-wrong-choice',
  templateUrl: './wrong-choice.component.html',
  styleUrls: ['./wrong-choice.component.css']
})
export class WrongChoiceComponent {

}
