import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'myAdd'
})
export class MyAddPipe implements PipeTransform 
{

  transform(value: number, Param : number): number 
  {
    let No1 : number = 8;
    let No2 : number = 3;
    
    let Res : number = No1+No2;
    return Res;
  }

}
