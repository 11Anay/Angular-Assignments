import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'myMult'
})
export class MyMultPipe implements PipeTransform 
{

  transform(value: number, Param: number): number 
  {
    let No1 : number = 7;
    let No2 : number = 3;
    let Res : number = No1 * No2;

    return Res;
  }

}
