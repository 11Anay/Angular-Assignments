import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'marvellousChk'
})
export class MarvellousChkPipe implements PipeTransform 
{

  transform(value: number, Param : string): any 
  {
    if(Param == "Prime")
    {
      if(value === 0)
      {
        return value + " is a not a prime nor composite number.";
      }
      else if(value === 2)
      {
        return value + " is a prime number!" ;
      }
      else
      {
        for(let i = 2; i < value; i++)
        {
          if(value % i === 0)
          {
            return value + " is not a prime number.";
          }
        }
        return value + " is a prime number!"
      }
    }
    if(Param == "Perfect")
    {
      let temp = 0;
      for(let i = 1; i < value; i++)
      {
        if(value % i === 0)
        {
          temp = temp + i;
        }
      }
      if(temp === value && temp != 0)
      {
        return value + " is a perfect number!";
      }
      else
      {
        return value + " is not a perfect number.";
      }
    }
    if(Param == "Even")
    {
      if(value % 2 === 0)
      {
        return value + " is an even number!";
      }
    }
    if(Param == "Odd")
    {
      if(value % 2 === 1)
      {
        return value + " is an odd number.";
      }
    }
  }
}
