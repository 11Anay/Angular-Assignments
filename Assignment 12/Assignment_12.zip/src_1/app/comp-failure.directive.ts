import { Directive, ElementRef, Host, HostListener } from '@angular/core';

@Directive({
  selector: '[appCompFailure]'
})
export class CompFailureDirective 
{

  constructor(public eboj : ElementRef) 
  { }

  @HostListener("mouseenter")onmouseenter()
  {
    this.eboj.nativeElement.style.color = "red";
  }
  @HostListener("mouseleave")onmouseleave()
  {
    this.eboj.nativeElement.style.color = "black";
  }
}
