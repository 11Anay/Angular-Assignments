import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent 
{
  firstname!: string;
  lastname!: string;
  phone! : number;
  email!: string;
  address! : string

  submit()
  {
    console.log("First Name : ",this.firstname);
    console.log("Last Name : ",this.lastname);
    console.log("Email : ",this.email);
    console.log("Phone : ",this.phone);
    console.log("Address : ",this.address);
  }
}
