import { Component } from '@angular/core';

@Component({
  selector: 'app-root',

  template : 
  `<h1 >Marvellous Infosystems</h1>
  <p>Marvellous Infosystems</p> `,

  styles : 
  [`
    h1,p
    {
      color : blue;
    }
  `]
})
export class AppComponent 
{
  title = 'Assignment6';
}
