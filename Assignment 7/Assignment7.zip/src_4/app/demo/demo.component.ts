import { Component } from '@angular/core';

@Component({
  selector: 'app-demo',
  templateUrl: './demo.component.html',
  styleUrls: ['./demo.component.css']
})
export class DemoComponent 
{
  public Data1 = " ";
  public Data2 = " ";

  public fun1()
  {
    this.Data1 = "Marvellous InfoSystems."
  }

  public fun2()
  {
    this.Data2 = "marvellous infosystems."
  }
  
}
