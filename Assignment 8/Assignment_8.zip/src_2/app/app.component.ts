import { Component} from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <h1>Parent Component</h1>
    <app-child [message]="parentMessage" (messageEvent)="receiveMessage($event)"></app-child>
    <p>{{childMessage}}</p>
`,
  styleUrls: ['./app.component.css']
})
export class AppComponent 
{
  parentMessage = "Hello from Parent";
  childMessage!: string;

  receiveMessage($event: string) {
    this.childMessage = $event;
  }
}
