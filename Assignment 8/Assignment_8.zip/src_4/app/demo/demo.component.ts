import { Component } from '@angular/core';

@Component({
  selector: 'app-demo',
  templateUrl: './demo.component.html',
  styleUrls: ['./demo.component.css']
})
export class DemoComponent 
{
  public data : string = " ";

  public GetMessage(name : any)
  {
    this.data = " Your entered message is : "+name+" and length of the message is : "+name.length;
  }
}
