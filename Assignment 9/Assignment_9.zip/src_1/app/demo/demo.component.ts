import { Component,OnInit } from '@angular/core';
import { ArithmeticService } from '../arithmetic.service';

@Component({
  selector: 'app-demo',
  templateUrl: './demo.component.html',
  styleUrls: ['./demo.component.css']
})
export class DemoComponent implements OnInit
{
  public addRes : any;
  public subRes : any;
  
  constructor(public aobj : ArithmeticService) {}
  ngOnInit(): void 
  {
    this.addRes = this.aobj.Add(11,10);
    this.subRes = this.aobj.Sub(11,10);
  }
}