import { Component,OnInit } from '@angular/core';
import { NumberService } from '../number.service';
import { StringService } from '../string.service';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit
{
  public CapCntRes : any;

  public PrimeRes : any;

  constructor( public nobj : NumberService, public sobj : StringService){}
  
  ngOnInit(): void 
  { 
    this.PrimeRes = this.nobj.ChkPrime(11);
    this.CapCntRes = this.sobj.CountCapital("Marvellous InfoSystems");
  }

}
